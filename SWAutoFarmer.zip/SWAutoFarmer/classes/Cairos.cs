﻿using SWAutoFarmer.assets;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWAutoFarmer
{
    internal class Cairos : BaseClass
    {
        private Timer TimerVictory;
        private Timer TimerCairosRuneOkClick;
        public Cairos(Form1 form, IntPtr noxPlayerWindow, Rectangle windowRect) : base(form, noxPlayerWindow, windowRect)
        {
            TimerVictory = new Timer();
            TimerVictory.Tick += new EventHandler(TimerVictory_Tick);
            TimerCairosRuneOkClick = new Timer();
            TimerCairosRuneOkClick.Tick += new EventHandler(TimerCairosRuneOkClick_Tick);
        }

        public override void PerformVictory()
        {
            if (tools.SearchBitmap(CapturedImage, Common.victory, ref pt))
            {
                TimerVictory.Interval = tools.GetValueInInterval();
                TimerVictory.Start();
            }
            else if (tools.SearchBitmap(CapturedImage, Common.reanimer, ref pt))
            {
                TimerPrepareClick.Start();
            }
        }

        public override void PerformFindingRune()
        {
            if (tools.SearchBitmap(CapturedImage, Common.sell, ref pt)) // on vend la rune
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - le bouton vendre a été trouvé", DateTime.Now.ToString("HH:mm:ss")));
                if (Mainform.chkBoxRareRune.Checked || Mainform.chkBoxHeroicRune.Checked || Mainform.chkBoxLegendary.Checked)
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - les options de recherche de runes sont cochées", DateTime.Now.ToString("HH:mm:ss")));
                    CheckRunes();
                }
                else
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on vend la rune", DateTime.Now.ToString("HH:mm:ss")));
                    TimerSellClick.Start();
                }
            }
            else // on va chercher l'image du ok
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - ce n'est pas une rune, on va chercher le bouton ok", DateTime.Now.ToString("HH:mm:ss")));
                TimerNotRuneOkClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerNotRuneOkClick.Start();
            }
        }
        public override void PerformFindingSellRuneYesButton()
        {
            if (tools.SearchBitmap(CapturedImage, Common.yes, ref pt))
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - le bouton oui a été trouvé", DateTime.Now.ToString("HH:mm:ss")));
                TimerYesClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerYesClick.Start();
            } else
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - le bouton oui n'a pas été trouvé (rune < 5*?)", DateTime.Now.ToString("HH:mm:ss")));
                NextRun();
            }
        }
        public override void PerformFindingOkButton()
        {
            if (tools.SearchBitmap(CapturedImage, assets.Cairos.ok, ref pt))
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - le bouton ok a été trouvé", DateTime.Now.ToString("HH:mm:ss")));
                TimerRuneOkClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerRuneOkClick.Start();
            }
        }

        private void TimerVictory_Tick(object sender, EventArgs e)
        {
            TimerVictory.Stop();
            TimerChestClick.Interval = tools.GetValueInInterval();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 450, 230, 300, 200, Mainform.lboxDebug);
            TimerChestClick.Start();
        }

        private void TimerCairosRuneOkClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on lance la gestion du bouton ok", DateTime.Now.ToString("HH:mm:ss")));
            TimerCairosRuneOkClick.Stop();
            Step = 4;
            TimerCheckImages.Start();
        }

        internal void CheckRunes()
        {
            bool runeFinded = false;
            if (Mainform.chkBoxLegendary.Checked && tools.SearchBitmap(CapturedImage, Common.legendary, ref pt))
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère les runes légendaires", DateTime.Now.ToString("HH:mm:ss")));
                if (Mainform.chkBoxSixStars.Checked && tools.SearchBitmap(CapturedImage, Common.six_star_legendary_row, ref pt))
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on a trouvé une rune 6*", DateTime.Now.ToString("HH:mm:ss")));
                      runeFinded = tools.CompareBitmap(Common.six_star_legendary_row,
                          CapturedImage.Clone(
                              new Rectangle(pt.X, pt.Y, Common.six_star_legendary_row.Width, Common.six_star_legendary_row.Height),
                              CapturedImage.PixelFormat));
                }
                if (!runeFinded && Mainform.chkBoxFiveStars.Checked 
                && tools.SearchBitmap(CapturedImage, Common.five_star_legendary_row, ref pt))
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on a trouvé une rune 5*", DateTime.Now.ToString("HH:mm:ss")));
                    runeFinded = tools.CompareBitmap(Common.five_star_legendary_row,
                        CapturedImage.Clone(
                            new Rectangle(pt.X, pt.Y, Common.five_star_legendary_row.Width, Common.five_star_legendary_row.Height),
                            CapturedImage.PixelFormat));
                }
            }
            if (!runeFinded && Mainform.chkBoxHeroicRune.Checked && tools.SearchBitmap(CapturedImage, Common.heroic, ref pt))
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère les runes héroiques", DateTime.Now.ToString("HH:mm:ss")));
                if (Mainform.chkBoxSixStars.Checked && tools.SearchBitmap(CapturedImage, Common.six_star_heroic_row, ref pt))
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on a trouvé une rune 6*", DateTime.Now.ToString("HH:mm:ss")));
                    runeFinded = tools.CompareBitmap(Common.six_star_heroic_row,
                        CapturedImage.Clone(
                            new Rectangle(pt.X, pt.Y, Common.six_star_heroic_row.Width, Common.six_star_heroic_row.Height),
                            CapturedImage.PixelFormat));
                }
                if (!runeFinded && Mainform.chkBoxFiveStars.Checked 
                    && tools.SearchBitmap(CapturedImage, Common.five_star_heroic_row, ref pt))
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on a trouvé une rune 5*", DateTime.Now.ToString("HH:mm:ss")));
                    runeFinded = tools.CompareBitmap(Common.five_star_heroic_row, 
                        CapturedImage.Clone(
                            new Rectangle(pt.X, pt.Y, Common.five_star_heroic_row.Width, Common.five_star_heroic_row.Height), 
                            CapturedImage.PixelFormat));
                }
            }
            if (!runeFinded && Mainform.chkBoxRareRune.Checked && tools.SearchBitmap(CapturedImage, Common.rare, ref pt))
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère les runes rares", DateTime.Now.ToString("HH:mm:ss")));
                if (Mainform.chkBoxSixStars.Checked && tools.SearchBitmap(CapturedImage, Common.six_star_rare_row, ref pt))
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on a trouvé une rune 6*", DateTime.Now.ToString("HH:mm:ss")));
                    runeFinded = tools.CompareBitmap(Common.six_star_rare_row,
                        CapturedImage.Clone(
                            new Rectangle(pt.X, pt.Y, Common.six_star_rare_row.Width, Common.six_star_rare_row.Height),
                            CapturedImage.PixelFormat));
                }
                if (!runeFinded && Mainform.chkBoxFiveStars.Checked 
                    && tools.SearchBitmap(CapturedImage, Common.five_star_rare_row, ref pt))
                {
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on a trouvé une rune 5*", DateTime.Now.ToString("HH:mm:ss")));
                    runeFinded = tools.CompareBitmap(Common.five_star_rare_row,
                        CapturedImage.Clone(
                            new Rectangle(pt.X, pt.Y, Common.five_star_rare_row.Width, Common.five_star_rare_row.Height),
                            CapturedImage.PixelFormat));
                }
            }
            // une rune a été trouvé, est-ce qu'on veut seulement de la vitesse ?
            if (runeFinded && Mainform.chkBoxOnlySpeed.Checked)
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère les runes avec de la vitesse", DateTime.Now.ToString("HH:mm:ss")));
                runeFinded = tools.SearchBitmap(CapturedImage, Common.rune_vit_2_rare, ref pt) || 
                    tools.SearchBitmap(CapturedImage, Common.vit, ref pt);
            }
            if (!runeFinded)
            {
                TimerSellClick.Start();
            } else
            {
                TimerCairosRuneOkClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerCairosRuneOkClick.Start();
            }
        }

        public override void Stop()
        {
            TimerVictory.Stop();
            TimerCairosRuneOkClick.Stop();
            base.Stop();
        }

        public override void Dispose()
        {
            TimerVictory.Dispose();
            TimerVictory = null;
            TimerCairosRuneOkClick.Dispose();
            TimerCairosRuneOkClick = null;
            base.Dispose();
        }

    }
}
