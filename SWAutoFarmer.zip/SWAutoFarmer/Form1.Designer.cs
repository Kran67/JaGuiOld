﻿namespace SWAutoFarmer
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grpBoxMode = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblRefill = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cboxAutoRefill = new System.Windows.Forms.CheckBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.cboxMode = new System.Windows.Forms.ComboBox();
            this.btnCapture = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkBoxOnlySpeed = new System.Windows.Forms.CheckBox();
            this.chkBoxLegendary = new System.Windows.Forms.CheckBox();
            this.chkBoxHeroicRune = new System.Windows.Forms.CheckBox();
            this.chkBoxRareRune = new System.Windows.Forms.CheckBox();
            this.chkBoxSixStars = new System.Windows.Forms.CheckBox();
            this.chkBoxFiveStars = new System.Windows.Forms.CheckBox();
            this.lboxDebug = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.picBoxCapture = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.grpBoxMode.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCapture)).BeginInit();
            this.SuspendLayout();
            // 
            // grpBoxMode
            // 
            this.grpBoxMode.Controls.Add(this.comboBox1);
            this.grpBoxMode.Controls.Add(this.lblRefill);
            this.grpBoxMode.Controls.Add(this.label1);
            this.grpBoxMode.Controls.Add(this.cboxAutoRefill);
            this.grpBoxMode.Controls.Add(this.btnStop);
            this.grpBoxMode.Controls.Add(this.btnStart);
            this.grpBoxMode.Controls.Add(this.cboxMode);
            this.grpBoxMode.Location = new System.Drawing.Point(12, 12);
            this.grpBoxMode.Name = "grpBoxMode";
            this.grpBoxMode.Size = new System.Drawing.Size(318, 73);
            this.grpBoxMode.TabIndex = 1;
            this.grpBoxMode.TabStop = false;
            this.grpBoxMode.Text = "Mode";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cairos",
            "Scénario",
            "Bête de rift",
            "Passage des dimensions"});
            this.comboBox1.Location = new System.Drawing.Point(6, 45);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 6;
            // 
            // lblRefill
            // 
            this.lblRefill.AutoSize = true;
            this.lblRefill.Location = new System.Drawing.Point(277, 51);
            this.lblRefill.Name = "lblRefill";
            this.lblRefill.Size = new System.Drawing.Size(13, 13);
            this.lblRefill.TabIndex = 5;
            this.lblRefill.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(191, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nombre de refill : ";
            // 
            // cboxAutoRefill
            // 
            this.cboxAutoRefill.AutoSize = true;
            this.cboxAutoRefill.Location = new System.Drawing.Point(191, 21);
            this.cboxAutoRefill.Name = "cboxAutoRefill";
            this.cboxAutoRefill.Size = new System.Drawing.Size(68, 17);
            this.cboxAutoRefill.TabIndex = 3;
            this.cboxAutoRefill.Text = "auto refill";
            this.cboxAutoRefill.UseVisualStyleBackColor = true;
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(133, 44);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(52, 23);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(133, 17);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(52, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // cboxMode
            // 
            this.cboxMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxMode.FormattingEnabled = true;
            this.cboxMode.Items.AddRange(new object[] {
            "Cairos",
            "Scénario",
            "Bête de rift",
            "Passage des dimensions"});
            this.cboxMode.Location = new System.Drawing.Point(6, 18);
            this.cboxMode.Name = "cboxMode";
            this.cboxMode.Size = new System.Drawing.Size(121, 21);
            this.cboxMode.TabIndex = 0;
            this.cboxMode.SelectedIndexChanged += new System.EventHandler(this.CboxMode_SelectedIndexChanged);
            // 
            // btnCapture
            // 
            this.btnCapture.Location = new System.Drawing.Point(100, 161);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(75, 25);
            this.btnCapture.TabIndex = 4;
            this.btnCapture.Text = "Capture";
            this.btnCapture.UseVisualStyleBackColor = true;
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkBoxOnlySpeed);
            this.groupBox1.Controls.Add(this.chkBoxLegendary);
            this.groupBox1.Controls.Add(this.chkBoxHeroicRune);
            this.groupBox1.Controls.Add(this.chkBoxRareRune);
            this.groupBox1.Controls.Add(this.chkBoxSixStars);
            this.groupBox1.Controls.Add(this.chkBoxFiveStars);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(12, 91);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(318, 66);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Keep Runes";
            // 
            // chkBoxOnlySpeed
            // 
            this.chkBoxOnlySpeed.AutoSize = true;
            this.chkBoxOnlySpeed.Enabled = false;
            this.chkBoxOnlySpeed.Location = new System.Drawing.Point(151, 46);
            this.chkBoxOnlySpeed.Name = "chkBoxOnlySpeed";
            this.chkBoxOnlySpeed.Size = new System.Drawing.Size(81, 17);
            this.chkBoxOnlySpeed.TabIndex = 5;
            this.chkBoxOnlySpeed.Text = "Only Speed";
            this.chkBoxOnlySpeed.UseVisualStyleBackColor = true;
            // 
            // chkBoxLegendary
            // 
            this.chkBoxLegendary.AutoSize = true;
            this.chkBoxLegendary.Location = new System.Drawing.Point(6, 23);
            this.chkBoxLegendary.Name = "chkBoxLegendary";
            this.chkBoxLegendary.Size = new System.Drawing.Size(76, 17);
            this.chkBoxLegendary.TabIndex = 4;
            this.chkBoxLegendary.Text = "Legendary";
            this.chkBoxLegendary.UseVisualStyleBackColor = true;
            this.chkBoxLegendary.CheckedChanged += new System.EventHandler(this.cboxTypeRune_CheckedChanged);
            // 
            // chkBoxHeroicRune
            // 
            this.chkBoxHeroicRune.AutoSize = true;
            this.chkBoxHeroicRune.Location = new System.Drawing.Point(88, 23);
            this.chkBoxHeroicRune.Name = "chkBoxHeroicRune";
            this.chkBoxHeroicRune.Size = new System.Drawing.Size(57, 17);
            this.chkBoxHeroicRune.TabIndex = 3;
            this.chkBoxHeroicRune.Text = "Heroic";
            this.chkBoxHeroicRune.UseVisualStyleBackColor = true;
            this.chkBoxHeroicRune.CheckedChanged += new System.EventHandler(this.cboxTypeRune_CheckedChanged);
            // 
            // chkBoxRareRune
            // 
            this.chkBoxRareRune.AutoSize = true;
            this.chkBoxRareRune.Location = new System.Drawing.Point(151, 23);
            this.chkBoxRareRune.Name = "chkBoxRareRune";
            this.chkBoxRareRune.Size = new System.Drawing.Size(49, 17);
            this.chkBoxRareRune.TabIndex = 2;
            this.chkBoxRareRune.Text = "Rare";
            this.chkBoxRareRune.UseVisualStyleBackColor = true;
            this.chkBoxRareRune.CheckedChanged += new System.EventHandler(this.cboxTypeRune_CheckedChanged);
            // 
            // chkBoxSixStars
            // 
            this.chkBoxSixStars.AutoSize = true;
            this.chkBoxSixStars.Checked = true;
            this.chkBoxSixStars.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBoxSixStars.Enabled = false;
            this.chkBoxSixStars.Location = new System.Drawing.Point(6, 46);
            this.chkBoxSixStars.Name = "chkBoxSixStars";
            this.chkBoxSixStars.Size = new System.Drawing.Size(57, 17);
            this.chkBoxSixStars.TabIndex = 1;
            this.chkBoxSixStars.Text = "6 stars";
            this.chkBoxSixStars.UseVisualStyleBackColor = true;
            this.chkBoxSixStars.CheckedChanged += new System.EventHandler(this.chkBoxSixStars_CheckedChanged);
            // 
            // chkBoxFiveStars
            // 
            this.chkBoxFiveStars.AutoSize = true;
            this.chkBoxFiveStars.Enabled = false;
            this.chkBoxFiveStars.Location = new System.Drawing.Point(88, 46);
            this.chkBoxFiveStars.Name = "chkBoxFiveStars";
            this.chkBoxFiveStars.Size = new System.Drawing.Size(57, 17);
            this.chkBoxFiveStars.TabIndex = 0;
            this.chkBoxFiveStars.Text = "5 stars";
            this.chkBoxFiveStars.UseVisualStyleBackColor = true;
            // 
            // lboxDebug
            // 
            this.lboxDebug.FormattingEnabled = true;
            this.lboxDebug.Location = new System.Drawing.Point(12, 342);
            this.lboxDebug.Name = "lboxDebug";
            this.lboxDebug.Size = new System.Drawing.Size(907, 199);
            this.lboxDebug.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 161);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // picBoxCapture
            // 
            this.picBoxCapture.InitialImage = ((System.Drawing.Image)(resources.GetObject("picBoxCapture.InitialImage")));
            this.picBoxCapture.Location = new System.Drawing.Point(336, 12);
            this.picBoxCapture.Name = "picBoxCapture";
            this.picBoxCapture.Size = new System.Drawing.Size(583, 324);
            this.picBoxCapture.TabIndex = 0;
            this.picBoxCapture.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 61000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 5000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(181, 161);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(76, 25);
            this.button2.TabIndex = 5;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(931, 548);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnCapture);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lboxDebug);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpBoxMode);
            this.Controls.Add(this.picBoxCapture);
            this.Name = "Form1";
            this.grpBoxMode.ResumeLayout(false);
            this.grpBoxMode.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCapture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox grpBoxMode;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        internal System.Windows.Forms.ComboBox cboxMode;
        internal System.Windows.Forms.CheckBox cboxAutoRefill;
        internal System.Windows.Forms.CheckBox chkBoxFiveStars;
        internal System.Windows.Forms.CheckBox chkBoxHeroicRune;
        internal System.Windows.Forms.CheckBox chkBoxRareRune;
        internal System.Windows.Forms.CheckBox chkBoxSixStars;
        internal System.Windows.Forms.CheckBox chkBoxLegendary;
        internal System.Windows.Forms.CheckBox chkBoxOnlySpeed;
        internal System.Windows.Forms.Button btnCapture;
        internal System.Windows.Forms.PictureBox picBoxCapture;
        internal System.Windows.Forms.ListBox lboxDebug;
        private System.Windows.Forms.Label lblRefill;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button2;
    }
}

