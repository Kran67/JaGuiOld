﻿using SWAutoFarmer.assets;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWAutoFarmer
{
    public partial class Form1 : Form
    {
        private IntPtr NoxPlayerWindow;
        private Rectangle windowRect = new Rectangle(-1912, 3, 1058, 627);
        private BaseClass currentClass = null;
        private int quizQuestionNumber = 0;

        public Form1()
        {
            InitializeComponent();
            NoxPlayerWindow = tools.GetWindowByName("NoxPlayer");
            tools.SetWindowPos(NoxPlayerWindow, IntPtr.Zero, windowRect.X, windowRect.Y, windowRect.Width, windowRect.Height, 0);
            cboxMode.SelectedIndex = 0;
        }

        ~Form1()
        {
            currentClass = null;
            NoxPlayerWindow = IntPtr.Zero;
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            btnStop.Enabled = true;
            currentClass.Run();
            lboxDebug.Items.Add(String.Format("{0} 1 - Captures toutes les {1} secondes", DateTime.Now.ToString("HH:mm:ss"), currentClass.TimerCapture.Interval / 1000));
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            currentClass.Stop();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            picBoxCapture.Image = tools.ResizeImage(tools.Capture(NoxPlayerWindow), 2f);
            picBoxCapture.Image.Save("capture.bmp", ImageFormat.Bmp);
        }

        //private void timerVictory_Tick(object sender, EventArgs e)
        //{
        //    lboxDebug.Items.Add(String.Format("{0} 5 - le timer1 se déclenche, on simule un clique dans la partie centrale de la /fenêtre/ pour faire apparaitre le coffre", DateTime.Now.ToString("HH:mm:ss")));
        //    timerVictory.Enabled = false;
        //    timerChestClick.Interval = tools.getValueInInterval();
        //    tools.clickOnArea(leftWindowPos, topWindowPos, 450, 230, 300, 200, lboxDebug);
        //    timerChestClick.Enabled = true;
        //}

        //private bool checkStars(bool result) // => ok
        //{
        //    if (result) // c'est une rune
        //    {
        //        result = false;
        //        if (cboxFiveStars.Checked)
        //        {
        //            result = tools.searchBitmap(CapturedImage, Common.five_stars_rare);
        //            if (result)
        //            {
        //                timerCairosRuneOkClick.Interval = tools.getValueInInterval(1000, 2500);
        //                timerCairosRuneOkClick.Enabled = true;
        //            }
        //        }
        //        if (cboxSixStars.Checked && !result)
        //        {
        //            //result = tools.searchBitmap(CapturedImage, Resource1.);
        //            if (result)
        //            {
        //                timerCairosRuneOkClick.Interval = tools.getValueInInterval(1000, 2500);
        //                timerCairosRuneOkClick.Enabled = true;
        //            }
        //        }
        //    }
        //    return result;
        //}

        //private void timerChestClick_Tick(object sender, EventArgs e) // => ok
        //{
        //    timerChestClick.Enabled = false;
        //    tools.clickOnArea(leftWindowPos, topWindowPos, 450, 230, 300, 200, lboxDebug);
        //    timerCairosRuneCheck.Enabled = true;
        //}

        //private void timerCairosRuneCheck_Tick(object sender, EventArgs e) // => ok
        //{
        //    timerCairosRuneCheck.Enabled = false;
        //    Step = 1;
        //    timerCheckImages.Interval = tools.getValueInInterval(1000, 2500);
        //    timerCheckImages.Enabled = true;
        //}

        //private void timerCairosSellClick_Tick(object sender, EventArgs e) // => ok
        //{
        //    lboxDebug.Items.Add(String.Format("{0} 13 - si le type ne correspond pas, on vend la rune", DateTime.Now.ToString//("HH:mm:ss")));
        //    timerCairosSellClick.Enabled = false;
        //    tools.clickOnArea(leftWindowPos, topWindowPos, 150, 70, 367, 477, lboxDebug);
        //    Step = 3;
        //    timerCheckImages.Interval = tools.getValueInInterval(1000, 2500);
        //    timerCheckImages.Enabled = true;
        //}

        //private void timerYesClick_Tick(object sender, EventArgs e) // => ok
        //{
        //    lboxDebug.Items.Add(String.Format("{0} 15 - on clique sur l'image oui", DateTime.Now.ToString("HH:mm:ss")));
        //    timerYesClick.Enabled = false;
        //    tools.clickOnArea(leftWindowPos, topWindowPos, 150, 70, 360, 350, lboxDebug);
        //    timerPlayAgain.Interval = tools.getValueInInterval(1000, 2500);
        //    timerPlayAgain.Enabled = true;
        //}

        //private void timerPlayAgain_Tick(object sender, EventArgs e) // => ok
        //{
        //    timerPlayAgain.Enabled = false;
        //    tools.clickOnArea(leftWindowPos, topWindowPos, 330, 80, 170, 310, lboxDebug);
        //    Step = 0;
        //}

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    btnCapture.PerformClick();
        //    Step = 4;
        //    //timerCheckImages_Tick(sender, e);
        //}

        //private void timerCairosNotRuneOkClick_Tick(object sender, EventArgs e)
        //{
        //    lboxDebug.Items.Add(String.Format("{0} 16 - on click dans la zone du bouton ok", DateTime.Now.ToString("HH:mm:ss")));
        //    timerCairosNotRuneOkClick.Enabled = false;
        //    tools.clickOnArea(leftWindowPos, topWindowPos, 150, 70, 455, 489, lboxDebug);
        //    timerPlayAgain.Interval = tools.getValueInInterval(1000, 2500);
        //    timerPlayAgain.Enabled = true;
        //}

        //private void timerCairosRuneOkClick_Tick(object sender, EventArgs e) // => ok
        //{
        //    lboxDebug.Items.Add(String.Format("{0} 16 - on click dans la zone du bouton ok", DateTime.Now.ToString("HH:mm:ss")));
        //    timerCairosNotRuneOkClick.Enabled = false;
        //    //tools.clickOnArea(leftWindowPos, topWindowPos, 150, 70, 545, 478, lboxDebug);
        //    //timerPlayAgain.Interval = tools.getValueInInterval(1000, 2500);
        //    //timerPlayAgain.Enabled = true;
        //}

        private void CboxMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (currentClass != null)
            {
                currentClass.Dispose();
                currentClass = null;
            }
            switch (cboxMode.SelectedIndex)
            {
                case 0: // Cairos
                    currentClass = new Cairos(this, NoxPlayerWindow, windowRect);
                    break;
                case 1: // Scénario
                    currentClass = new Scenarii(this, NoxPlayerWindow, windowRect);
                    break;
                case 2: // Bêtes de rift
                    currentClass = new BeastRift(this, NoxPlayerWindow, windowRect);
                    break;
                case 3: // Passage des dimenssions
                    currentClass = new DimensionPassage(this, NoxPlayerWindow, windowRect);
                    break;
            }
            groupBox1.Enabled = cboxMode.SelectedIndex == 0;

        }

        private void cboxTypeRune_CheckedChanged(object sender, EventArgs e)
        {
            chkBoxFiveStars.Enabled = chkBoxSixStars.Enabled = chkBoxOnlySpeed.Enabled =
                chkBoxLegendary.Checked || chkBoxHeroicRune.Checked || chkBoxRareRune.Checked;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 19, 14, 1069, 600, lboxDebug); // réduction des fenêtres
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 16, 16, 711, 159, lboxDebug); // fermeture de la fenêtre SW
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 56, 56, 731, 177, lboxDebug); // lancement de SW
            Point pt = new Point();
            //if (tools.SearchBitmap((Bitmap)picBoxCapture.Image, Common.touch, ref pt))
            //{
            //    tools.ClickOnArea(windowRect.X, windowRect.Y, windowRect.Width-10, windowRect.Height-10, 5, 5, lboxDebug);
            //}
            //if (tools.SearchBitmap((Bitmap)picBoxCapture.Image, Common.close_chest_window, ref pt)) // ferme le coffre
            //{
            //    tools.ClickOnArea(windowRect.X, windowRect.Y, 12, 13, 937, 109, lboxDebug);
            //}
            //if (tools.SearchBitmap((Bitmap)picBoxCapture.Image, Common.close_first_window, ref pt)) // ferme la première fenêtre 
            //{
            //    tools.ClickOnArea(windowRect.X, windowRect.Y, 27, 29, 908, 48, lboxDebug);
            //}
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 111, 73, 759, 436, lboxDebug); // clique sur le portail de téléportation
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 70, 72, 661, 539, lboxDebug); // clique sur l'icône téléporteur
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 370, 87, 650, 127, lboxDebug); // clique sur l'item Cairos
            //tools.ClickOnArea(windowRect.X, windowRect.Y, 370, 14, 650, 515, lboxDebug); // clique sur l'item Donjon du Rift
            timer1.Start();
        }

        private void chkBoxSixStars_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            tools.ClickOnArea(windowRect.X, windowRect.Y, 139, 56, 460, 363, lboxDebug);
            timer2.Start();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            picBoxCapture.Image = tools.ResizeImage(tools.Capture(NoxPlayerWindow), 2f);
            picBoxCapture.Image.Save(String.Format("../../assets/images/quiz/ecran question{0}.bmp", ++quizQuestionNumber), ImageFormat.Bmp);
            timer1.Start();
        }
    }
}


/*
0 - Lancement du donjon
1 - Captures toutes les 15 secondes
2 - Vérification de l'image Victory
3 - Si l'image est pas trouvée retour n°2
4 - Si l'image est trouvée, on choisit un chiffre entre 1 et 5 on l'assigne au timer1
5 - le timer1 se déclenche, on simule un clique dans la partie centrale de la fenêtre pour faire apparaitre le coffre
6 - on choisit un chiffre entre 1 et 5 on l'assigne au timer2
7 - le timer2 se déclenche, on simule un clique dans la partie centrale de la fenêtre pour faire apparaitre le loot
8 - si on a des options de runes, on check les images d'étoiles
9 - si on trouve pas d'images, go étape n°15
10 - on teste le nombre d'étoiles correspondant aux options, sinon go étape n°14
11 - le nombre correspond aux options, on teste le type de runes correspondant aux options, sinon go étape n°14
12 - le type correspond aux options, on passe à l'étape n°15
13 - si le type ne correspond pas, on vend la rune
14 - on cherche l'image oui
15 - on cherche l'image ok
16 - on click dans la zone du bouton ok
17 - on cherche l'image rejouer
18 - on click dans la zone du bouton rejouer


réanimation -> non -> clique dans la partie centrale de la fenêtre -> clique préparation -> clique go

en fonction du nombre de run augmenter le range des cliques
faire une pause de 20 < x > 30 minutes après 150 < x > 250 runs

 */
