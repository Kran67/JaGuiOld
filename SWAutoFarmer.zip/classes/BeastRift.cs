﻿using SWAutoFarmer.assets;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWAutoFarmer
{
    internal class BeastRift : BaseClass
    {
        private Timer TimerResult;
        public BeastRift(Form1 form, IntPtr noxPlayerWindow, Rectangle windowRect) : base(form, noxPlayerWindow, windowRect)
        {
            TimerResult = new Timer();
            TimerResult.Tick += new EventHandler(TimerResult_Tick);
        }

        private void TimerResult_Tick(object sender, EventArgs e)
        {
            TimerResult.Stop();
            TimerChestClick.Interval = tools.GetValueInInterval();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 450, 230, 300, 200, Mainform.lboxDebug);
            TimerChestClick.Start();
        }

        public override void PerformVictory()
        {
            if (tools.SearchBitmap(CapturedImage, Beasts.result, ref pt))
            {
                TimerResult.Interval = tools.GetValueInInterval();
                TimerResult.Start();
            }
        }

        public override void PerformFindingRune() {}
        public override void PerformFindingSellRuneYesButton() {}
        public override void PerformFindingOkButton(){
            if (tools.SearchBitmap(CapturedImage, Beasts.ok, ref pt))
            {
                Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - le bouton ok a été trouvé", DateTime.Now.ToString("HH:mm:ss")));
                TimerNotRuneOkClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerNotRuneOkClick.Start();
            }
        }

        public override void Stop()
        {
            TimerResult.Stop();
            base.Stop();
        }

        public override void Dispose()
        {
            TimerResult.Dispose();
            TimerResult = null;
            base.Dispose();
        }
    }
}
