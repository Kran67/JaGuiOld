﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Imaging;
using Image = System.Drawing.Image;
using SWAutoFarmer.classes;

namespace SWAutoFarmer
{
    internal static class tools
    {
        // Define the SetWindowPos API function.
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool SetWindowPos(IntPtr hWnd,
            IntPtr hWndInsertAfter, int X, int Y, int cx, int cy,
            SetWindowPosFlags uFlags);
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool GetWindowRect(IntPtr hWnd, ref Rect lpRect);
        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, int nFlags);
        [DllImport("User32.Dll")]
        public static extern long SetCursorPos(int x, int y);
        [DllImport("user32.dll")]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);
        // Define the SetWindowPosFlags enumeration.
        [Flags()]
        internal enum SetWindowPosFlags : uint
        {
            SynchronousWindowPosition = 0x4000,
            DeferErase = 0x2000,
            DrawFrame = 0x0020,
            FrameChanged = 0x0020,
            HideWindow = 0x0080,
            DoNotActivate = 0x0010,
            DoNotCopyBits = 0x0100,
            IgnoreMove = 0x0002,
            DoNotChangeOwnerZOrder = 0x0200,
            DoNotRedraw = 0x0008,
            DoNotReposition = 0x0200,
            DoNotSendChangingEvent = 0x0400,
            IgnoreResize = 0x0001,
            IgnoreZOrder = 0x0004,
            ShowWindow = 0x0040,
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct Rect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        internal const int MOUSEEVENTF_LEFTDOWN = 0x02;
        internal const int MOUSEEVENTF_LEFTUP = 0x04;
        internal const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        internal const int MOUSEEVENTF_RIGHTUP = 0x10;

        internal static IntPtr GetWindowByName(string wName)
        {
            IntPtr hWnd = IntPtr.Zero;
            foreach (Process pList in Process.GetProcesses())
            {
                if (pList.MainWindowTitle.Contains(wName))
                {
                    hWnd = pList.MainWindowHandle;
                }
            }
            return hWnd;
        }

        internal static Bitmap Capture(IntPtr hWnd)
        {
            Rectangle bounds;

            var rect = new Rect();
            GetWindowRect(hWnd, ref rect);
            bounds = new Rectangle(rect.Left, rect.Top, rect.Right - rect.Left, rect.Bottom - rect.Top);
            Bitmap bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb);
            Graphics gfxBmp = Graphics.FromImage(bmp);
            IntPtr hdcBitmap = gfxBmp.GetHdc();

            PrintWindow(hWnd, hdcBitmap, 0);

            gfxBmp.ReleaseHdc(hdcBitmap);
            gfxBmp.Dispose();

            return bmp;
        }

        internal static Bitmap ResizeImage(Bitmap img, float coef)
        {
            int width = (int)(img.Width / coef);
            int height = (int)(img.Height / coef);
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height, PixelFormat.Format24bppRgb);

            destImage.SetResolution(img.HorizontalResolution, img.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighSpeed;
                graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
                graphics.SmoothingMode = SmoothingMode.None;
                graphics.PixelOffsetMode = PixelOffsetMode.HighSpeed;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(img, destRect, 0, 0, img.Width, img.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }

        internal static bool SearchBitmap(Bitmap bigBmp, Bitmap smallBmp, ref Point pt)
        {
            // create template matching algorithm's instance
            // (set similarity threshold to 92.1%)

            ExhaustiveTemplateMatching tm = new ExhaustiveTemplateMatching(0.921f);
            // find all matchings with specified above similarity

            TemplateMatch[] matchings = tm.ProcessImage(bigBmp, smallBmp);
            // highlight found matchings
            if (matchings.Length > 0)
            {
                pt.X = matchings[0].Rectangle.X;
                pt.Y = matchings[0].Rectangle.Y;
            }
            return matchings.Length > 0;
        }

        internal static int GetValueInInterval(int min = 1000, int max = 5000)
        {
            Random r = new Random();
            return r.Next(min, max);
        }

        internal static void ClickOnArea(int left, int top, int width, int height, int offsetX, int offsetY, ListBox listBox)
        {
            int leftArea = left + offsetX;
            int topArea = top + offsetY;
            int x = GetValueInInterval(leftArea, leftArea + width);
            int y = GetValueInInterval(topArea, topArea + height);
            SetCursorPos(x, y);
            listBox.Items.Insert(0, String.Format("{0} positionnement de la souris dans la zone x:{1}, y:{2}, left:{3}, top:{4}, width:{5}, height:{6}", DateTime.Now.ToString("HH:mm:ss"), x, y, leftArea, topArea, leftArea + width, topArea + height));
            mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0);
            mouse_event(MOUSEEVENTF_LEFTUP, x, y, 0, 0);
        }

        internal static bool CompareBitmap(Bitmap bmp1, Bitmap bmp2)
        {
            BitmapData BmpDt1 = bmp1.LockBits(new Rectangle(0, 0, bmp1.Width, bmp1.Height), ImageLockMode.ReadWrite, bmp1.PixelFormat);
            IntPtr pointer = BmpDt1.Scan0;
            int size = Math.Abs(BmpDt1.Stride) * bmp1.Height;
            byte[] pixelsBmp1 = new byte[size];
            Marshal.Copy(pointer, pixelsBmp1, 0, size);
            bmp1.UnlockBits(BmpDt1);
            BitmapData BmpDt2 = bmp2.LockBits(new Rectangle(0, 0, bmp2.Width, bmp2.Height), ImageLockMode.ReadWrite, bmp2.PixelFormat);
            pointer = BmpDt2.Scan0;
            size = Math.Abs(BmpDt2.Stride) * bmp1.Height;
            byte[] pixelsBmp2 = new byte[size];
            Marshal.Copy(pointer, pixelsBmp2, 0, size);
            bmp2.UnlockBits(BmpDt2);
            return pixelsBmp1.Length == pixelsBmp2.Length && pixelsBmp1.SequenceEqual(pixelsBmp2);
        }
    }
}
