﻿using SWAutoFarmer.assets;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWAutoFarmer
{
    internal class DimensionPassage : BaseClass
    {
        private Timer TimerVictory;
        public DimensionPassage(Form1 form, IntPtr noxPlayerWindow, Rectangle windowRect) : base(form, noxPlayerWindow, windowRect)
        {
            TimerVictory = new Timer();
            TimerVictory.Tick += new EventHandler(TimerVictory_Tick);
        }

        private void TimerVictory_Tick(object sender, EventArgs e)
        {
            TimerVictory.Stop();
            TimerChestClick.Interval = tools.GetValueInInterval();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 450, 230, 300, 200, Mainform.lboxDebug);
            TimerChestClick.Start();
        }

        public override void PerformVictory()
        {
            bool result = tools.SearchBitmap(CapturedImage, Common.victory, ref pt);
            if (result)
            {
                TimerVictory.Interval = tools.GetValueInInterval();
                TimerVictory.Start();
            }
        }

        public override void PerformFindingRune()
        {

        }
        public override void PerformFindingSellRuneYesButton()
        {

        }
        public override void PerformFindingOkButton()
        {
            if (tools.SearchBitmap(CapturedImage, Common.ok, ref pt))
            {
                TimerNotRuneOkClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerNotRuneOkClick.Start();
            }
        }

        public override void Stop()
        {
            TimerVictory.Stop();
            base.Stop();
        }

        public override void Dispose()
        {
            TimerVictory.Dispose();
            TimerVictory = null;
            base.Dispose();
        }
    }
}
