﻿using SWAutoFarmer.assets;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWAutoFarmer
{
    internal class Scenarii : BaseClass
    {
        private Timer TimerVictory;
        public Scenarii(Form1 form, IntPtr noxPlayerWindow, Rectangle windowRect) : base(form, noxPlayerWindow, windowRect)
        {
            TimerVictory = new Timer();
            TimerVictory.Tick += new EventHandler(TimerVictory_Tick);
        }

        private void TimerVictory_Tick(object sender, EventArgs e)
        {
            TimerVictory.Stop();
            TimerChestClick.Interval = tools.GetValueInInterval();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 450, 230, 300, 200, Mainform.lboxDebug);
            TimerChestClick.Start();
        }

        public override void PerformVictory()
        {
            bool result = tools.SearchBitmap(CapturedImage, Common.victory, ref pt);
            if (result)
            {
                TimerVictory.Interval = tools.GetValueInInterval();
                TimerVictory.Start();
            } else if (tools.SearchBitmap(CapturedImage, Common.reanimer, ref pt))
            {
                tools.ClickOnArea(WindowRect.X, WindowRect.Y, 450, 230, 300, 200, Mainform.lboxDebug);
                TimerPrepareClick.Start();
            }
        }

        public override void PerformFindingRune()
        {
            if (tools.SearchBitmap(CapturedImage, Common.sell, ref pt)) // on vend la rune
            {
                TimerSellClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerSellClick.Start();
            }
            else // on va chercher l'image du ok
            {
                TimerNotRuneOkClick.Start();
            }
        }
        public override void PerformFindingSellRuneYesButton()
        {
            if (tools.SearchBitmap(CapturedImage, Common.yes, ref pt))
            {
                TimerYesClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerYesClick.Start();
            }
        }
        public override void PerformFindingOkButton()
        {
            if (tools.SearchBitmap(CapturedImage, assets.Scenarii.ok, ref pt))
            {
                TimerNotRuneOkClick.Interval = tools.GetValueInInterval(1000, 2500);
                TimerNotRuneOkClick.Start();
            }
        }

        public override void Stop()
        {
            TimerVictory.Stop();
            base.Stop();
        }

        public override void Dispose()
        {
            TimerVictory.Dispose();
            TimerVictory = null;
            base.Dispose();
        }
    }
}
