﻿using SWAutoFarmer.assets;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWAutoFarmer
{
    internal abstract class BaseClass : IDisposable
    {
        public int Step = 0;
        public Bitmap CapturedImage;
        internal Timer TimerCapture;
        internal Timer TimerCheckImages;
        internal Timer TimerChestClick;
        internal Timer TimerPlayAgain;
        internal IntPtr NoxPlayerWindow;
        internal Rectangle WindowRect;
        internal Form1 Mainform;
        internal Timer TimerSellClick;
        internal Timer TimerRuneCheck;
        internal Timer TimerNotRuneOkClick;
        internal Timer TimerNotRuneOkClick2;
        internal Timer TimerRuneOkClick;
        internal Timer TimerYesClick;
        internal Timer TimerPrepareClick;
        internal Timer TimerGoClick;
        internal Point pt = new Point();

        public BaseClass(Form1 form, IntPtr noxPlayerWindow, Rectangle windowRect)
        {
            Mainform = form;
            NoxPlayerWindow = noxPlayerWindow;
            WindowRect = windowRect;
            TimerCapture = new Timer
            {
                Interval = 10000
            };
            TimerCapture.Tick += new EventHandler(TimerCapture_Tick);
            TimerCheckImages = new Timer
            {
                Interval = 1000
            };
            TimerCheckImages.Tick += new EventHandler(TimerCheckImages_Tick);
            TimerChestClick = new Timer();
            TimerChestClick.Tick += new EventHandler(TimerChestClick_Tick);
            TimerPlayAgain = new Timer();
            TimerPlayAgain.Tick += new EventHandler(TimerPlayAgain_Tick);
            TimerSellClick = new Timer();
            TimerSellClick.Tick += new EventHandler(TimerSellClick_Tick);
            TimerRuneCheck = new Timer();
            TimerRuneCheck.Tick += new EventHandler(TimerRuneCheck_Tick);
            TimerNotRuneOkClick = new Timer();
            TimerNotRuneOkClick.Tick += new EventHandler(TimerNotRuneOkClick_Tick);
            TimerNotRuneOkClick2 = new Timer();
            TimerNotRuneOkClick2.Tick += new EventHandler(TimerNotRuneOkClick2_Tick);
            TimerYesClick = new Timer();
            TimerYesClick.Tick += new EventHandler(TimerYesClick_Tick);
            TimerPrepareClick = new Timer();
            TimerPrepareClick.Tick += new EventHandler(TimerPrepareClick_Tick);
            TimerGoClick = new Timer();
            TimerGoClick.Tick += new EventHandler(TimerGoClick_Tick);
            TimerRuneOkClick = new Timer();
            TimerRuneOkClick.Tick += new EventHandler(TimerRuneOkClick_Tick);
        }

        public void Run()
        {
            TimerCapture.Start();
        }

        public virtual void Stop()
        {
            TimerCapture.Stop();
            TimerCheckImages.Stop();
            TimerChestClick.Stop();
            TimerPlayAgain.Stop();
            TimerSellClick.Stop();
            TimerRuneCheck.Stop();
            TimerNotRuneOkClick.Stop();
            TimerNotRuneOkClick2.Stop();
            TimerRuneOkClick.Stop();
            TimerYesClick.Stop();
            TimerPrepareClick.Stop();
            TimerGoClick.Stop();
        }
        public abstract void PerformVictory();
        public abstract void PerformFindingRune();
        public abstract void PerformFindingSellRuneYesButton();
        public abstract void PerformFindingOkButton();

        private void Capture_window()
        {
            CapturedImage = tools.ResizeImage(tools.Capture(NoxPlayerWindow), 2f);
            Mainform.picBoxCapture.Image = CapturedImage;
            TimerCheckImages.Start();
        }

        private void TimerCapture_Tick(object sender, EventArgs e)
        {
            Capture_window();
        }

        private void TimerCheckImages_Tick(object sender, EventArgs e)
        {
            Capture_window();
            TimerCheckImages.Stop();
            switch (Step)
            {
                case 0: // Victory
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère la victoire", DateTime.Now.ToString("HH:mm:ss")));
                    PerformVictory();
                    break;
                case 1: // find rune loot
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère le loot", DateTime.Now.ToString("HH:mm:ss")));
                    PerformFindingRune();
                    break;
                case 2: // find replay
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère le bouton rejouer", DateTime.Now.ToString("HH:mm:ss")));
                    if (!tools.SearchBitmap(CapturedImage, Common.rerun, ref pt))
                    {
                        NextRun();
                    } else
                    {
                        TimerCheckImages.Start();
                    }
                    break;
                case 3: // find sell rune yes
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère la vente de rune", DateTime.Now.ToString("HH:mm:ss")));
                    PerformFindingSellRuneYesButton();
                    break;
                case 4: // find ok
                    Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on gère le bouton ok", DateTime.Now.ToString("HH:mm:ss")));
                    PerformFindingOkButton();
                    break;
            }
        }

        private void TimerChestClick_Tick(object sender, EventArgs e)
        {
            TimerChestClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 450, 230, 300, 200, Mainform.lboxDebug);
            if (this is Cairos || this is Scenarii)
            {
                TimerRuneCheck.Start();
            } else
            {
                Step = 4;
                TimerCheckImages.Interval = tools.GetValueInInterval(1000, 2500);
                TimerCheckImages.Start();
            }
        }

        private void TimerSellClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton vendre", DateTime.Now.ToString("HH:mm:ss")));
            TimerSellClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 61, 370, 479, Mainform.lboxDebug);
            Step = 3;
            TimerCheckImages.Interval = tools.GetValueInInterval(1000, 2500);
            TimerCheckImages.Start();
        }

        private void TimerPlayAgain_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le rejouer", DateTime.Now.ToString("HH:mm:ss")));
            TimerPlayAgain.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 317, 71, 180, 318, Mainform.lboxDebug);
            Step = 0;
        }

        private void TimerRuneCheck_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on va gèrer les runes", DateTime.Now.ToString("HH:mm:ss")));
            TimerRuneCheck.Stop();
            Step = 1;
            TimerCheckImages.Interval = tools.GetValueInInterval(1000, 2500);
            TimerCheckImages.Start();
        }

        private void TimerNotRuneOkClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton ok", DateTime.Now.ToString("HH:mm:ss")));
            TimerNotRuneOkClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 61, 458, 457, Mainform.lboxDebug);
            Step = 2;
            TimerCheckImages.Interval = tools.GetValueInInterval(1000, 2500);
            TimerCheckImages.Start();
        }

        private void TimerNotRuneOkClick2_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton ok", DateTime.Now.ToString("HH:mm:ss")));
            TimerNotRuneOkClick2.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 58, 458, 493, Mainform.lboxDebug);
            Step = 2;
            TimerCheckImages.Interval = tools.GetValueInInterval(1000, 2500);
            TimerCheckImages.Start();
        }

        private void TimerRuneOkClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton ok", DateTime.Now.ToString("HH:mm:ss")));
            TimerRuneOkClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 61, 546, 479, Mainform.lboxDebug);
            NextRun();
        }

        private void TimerYesClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton oui", DateTime.Now.ToString("HH:mm:ss")));
            TimerYesClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 61, 365, 359, Mainform.lboxDebug);
            TimerPlayAgain.Interval = tools.GetValueInInterval(1000, 2500);
            TimerPlayAgain.Start();
        }

        private void TimerPrepareClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton préparation", DateTime.Now.ToString("HH:mm:ss")));
            TimerPrepareClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 61, 365, 359, Mainform.lboxDebug);
            TimerGoClick.Interval = tools.GetValueInInterval(1000, 2500);
            TimerGoClick.Start();
        }

        private void TimerGoClick_Tick(object sender, EventArgs e)
        {
            Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - on clique sur le bouton go", DateTime.Now.ToString("HH:mm:ss")));
            TimerGoClick.Stop();
            tools.ClickOnArea(WindowRect.X, WindowRect.Y, 142, 61, 365, 359, Mainform.lboxDebug);
        }

        internal void NextRun()
        {
            //Mainform.lboxDebug.Items.Insert(0, String.Format("{0} - nouveau run", DateTime.Now.ToString("HH:mm:ss")));
            Mainform.lboxDebug.Items.Clear();
            TimerPlayAgain.Interval = tools.GetValueInInterval(1000, 2500);
            TimerPlayAgain.Start();
        }

        public virtual void Dispose()
        {
            TimerCapture.Dispose();
            TimerCapture = null;
            TimerCheckImages.Dispose();
            TimerCheckImages = null;
            TimerChestClick.Dispose();
            TimerChestClick = null;
            TimerPlayAgain.Dispose();
            TimerPlayAgain = null;
            TimerSellClick.Dispose();
            TimerSellClick = null;
            TimerRuneCheck.Dispose();
            TimerRuneCheck = null;
            TimerNotRuneOkClick.Dispose();
            TimerNotRuneOkClick = null;
            TimerNotRuneOkClick2.Dispose();
            TimerNotRuneOkClick2 = null;
            TimerYesClick.Dispose();
            TimerYesClick = null;
            TimerPrepareClick.Dispose();
            TimerPrepareClick = null;
            TimerGoClick.Dispose();
            TimerGoClick = null;
        }
    }
}
