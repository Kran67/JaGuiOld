﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SelectionSolution
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public BitmapImage BitmapImage {
			get
			{
				return new BitmapImage(new Uri(@"pack://application:,,,/example-air-picture.PNG")); // dirty quick local URI
			}
		}

		public MainWindow()
		{
			InitializeComponent();
			this.DataContext = this;
		}
	}
}
