transform.duration = (function(Utils){

    var formats = ['y','M','w','d','h','m','s','ms'];
    var l = formats.length;

    return function(format,cascade) {

        return function(value){

            var i=0;
            var result = [];
            var remaining = value;
            var used,key,required;

            for(;i<l;i++) {

                key = formats[i];
                required = Utils.AMOUNT[key];

                // how much is used by this format type
                used = Math.floor(remaining / required);

                // is this format type is used in a slot calculate what's left
                if (format.indexOf(key) !== -1) {

                    // subtract
                    remaining = remaining % required;

                    // and add results
                    result.push(Math.max(0,used));

                }
                else if (!cascade) {

                    // if we're not cascading act as if we used up the value
                    remaining = remaining % required;
                }

            }

            return result;

        }

    };

}(utils));
