// expose as jQuery plugin
(function(factory,$){

    // if no jquery, stop here
    if (!$) {return;}

    // setup plugin
    $.fn.soon = function(options) {
        options = options || {};
        return this.each(function() {
            factory.create(this,options);
        });
    };

    $.fn.soon.destroy = function() {
        return this.each(function() {
            factory.destroy(this);
        });
    };

    $.fn.soon.reset = function() {
        return this.each(function() {
            factory.reset(this);
        });
    };

    $.fn.soon.resize = function() {
        return this.each(function() {
            factory.resize(this);
        });
    };

    $.fn.soon.freeze = function() {
        return this.each(function() {
            factory.freeze(this);
        });
    };

    $.fn.soon.unfreeze = function() {
        return this.each(function() {
            factory.unfreeze(this);
        });
    };

    $.fn.soon.setOption = function(property,value) {
        return this.each(function() {
            factory.setOption(this,property,value);
        });
    };

}(exports,jQuery));